﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Options : MonoBehaviour {

	/*// Use this for initialization
    void Start () {
        
    }
    
    // Update is called once per frame
    void Update () {
        
    }*/

	public Slider BGMSlider;
	public Slider SFXSlider;
	public AudioSource bgmAudio;
	public AudioSource sfxAudio;
	public Toggle nightToggle;

	public void changeBGMVolume (){
		BGMSlider.value = bgmAudio.volume;
	}

	public void changeSFXVolume(){
		SFXSlider.value = sfxAudio.volume;
	}

	public void toggleNight(){
		while (nightToggle.isOn) {

		}
	}
} 

